package com.neuropulse.capture

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.os.Bundle
import android.os.SystemClock
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var button: Button
    private val executor = Executors.newSingleThreadExecutor()
    private val capturing = AtomicBoolean(false)
    private var captureStartNs = 0L
    private var sessionDir: File? = null
    private var csv: File? = null
    private var frameIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview); status = findViewById(R.id.status); timer = findViewById(R.id.timer); button = findViewById(R.id.startStop)
        button.setOnClickListener { if (capturing.get()) stopCapture() else startCapture() }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
        } else startCamera()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUse = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build()
            analysis.setAnalyzer(executor) { image -> analyze(image) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUse, analysis)
            status.text = "Ready — rear camera / flash OFF / 30 FPS target"
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startCapture() {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        sessionDir = File(getExternalFilesDir(null), "NeuroPulse_$stamp").apply { mkdirs(); File(this, "frames").mkdirs() }
        csv = File(sessionDir, "frames.csv").also { it.writeText("frame_index,elapsed_ms,image_timestamp_ns,width,height,mean_y\n") }
        frameIndex = 0; captureStartNs = System.nanoTime(); capturing.set(true)
        button.text = "STOP CAPTURE"; status.text = "CAPTURING — keep eye steady; no flash"
    }

    private fun stopCapture() {
        capturing.set(false); button.text = "START 10 s CAPTURE"
        status.text = "Saved: ${sessionDir?.absolutePath ?: "—"}"
    }

    private fun analyze(image: ImageProxy) {
        try {
            if (!capturing.get()) return
            val elapsedMs = (System.nanoTime() - captureStartNs) / 1_000_000L
            if (elapsedMs >= 10_000L) { runOnUiThread { stopCapture() }; return }
            val idx = frameIndex++
            val yPlane = image.planes[0]
            val buffer = yPlane.buffer
            val bytes = ByteArray(buffer.remaining()); buffer.get(bytes)
            var sum = 0L; for (b in bytes) sum += (b.toInt() and 0xFF)
            val meanY = if (bytes.isNotEmpty()) sum.toDouble() / bytes.size else 0.0
            val jpeg = yuvToJpeg(image)
            val frameFile = File(sessionDir, "frames/frame_${String.format(Locale.US, "%05d", idx)}.jpg")
            FileOutputStream(frameFile).use { it.write(jpeg) }
            csv?.appendText("$idx,$elapsedMs,${image.imageInfo.timestamp},${image.width},${image.height},${"%.3f".format(Locale.US, meanY)}\n")
            runOnUiThread { timer.text = String.format(Locale.US, "%.1f s", elapsedMs / 1000.0) }
        } finally { image.close() }
    }

    private fun yuvToJpeg(image: ImageProxy): ByteArray {
        val y = image.planes[0].buffer; val u = image.planes[1].buffer; val v = image.planes[2].buffer
        val yBytes = ByteArray(y.remaining()); y.get(yBytes); val uBytes = ByteArray(u.remaining()); u.get(uBytes); val vBytes = ByteArray(v.remaining()); v.get(vBytes)
        val nv21 = ByteArray(yBytes.size + uBytes.size + vBytes.size)
        System.arraycopy(yBytes, 0, nv21, 0, yBytes.size)
        var p = yBytes.size
        var i = 0
        while (i < vBytes.size && i < uBytes.size) { nv21[p++] = vBytes[i]; nv21[p++] = uBytes[i]; i++ }
        val out = ByteArrayOutputStream()
        YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null).compressToJpeg(Rect(0, 0, image.width, image.height), 90, out)
        return out.toByteArray()
    }

    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
