# Build the NeuroPulse APK online with GitHub Actions

This project is prepared to build a debug APK in GitHub's hosted runner.

## Phone-only procedure
1. Open https://github.com/ and sign in or create a free account.
2. Create a new repository, for example `NeuroPulse-F14-Capture`.
3. Upload the contents of this project ZIP (upload the files/folders inside `NeuroPulse_F14_Capture`, not the outer folder itself).
4. Commit the files to `main`.
5. Open the repository's **Actions** tab.
6. Select **Build NeuroPulse APK**.
7. If it has not run automatically, choose **Run workflow** and start it.
8. Wait for the workflow to finish with a green check.
9. Open the completed workflow run. Under **Artifacts**, download `NeuroPulse-F14-debug-apk`.
10. Extract the downloaded ZIP. Inside is `app-debug.apk`.
11. Transfer/install the APK on the Samsung Galaxy F14 5G.

## What this build is
- Debug APK for the first-stage capture experiment.
- Rear-camera acquisition.
- Flash OFF.
- Up to 10 seconds of frame capture.
- JPEG frames + CSV timestamps/luminance.

## What it is NOT
- Not a clinically validated pupillometer.
- Does not establish true optical stimulus timing.
- Does not yet contain the trained U-Net weights or PLR onset validation.

For a release/public APK, use a properly signed release build rather than the debug APK.
