# NeuroPulse F14 Capture v0.1.0

Target device: Samsung Galaxy F14 5G (SM-E146B/DS), Android 15, One UI 7.0, 6 GB RAM, 128 GB.

## Purpose
This is the **first-stage acquisition app** for a single-eye real-world feasibility experiment. It uses the rear camera and intentionally keeps the phone flash OFF. It captures up to 10 seconds of YUV frames, converts them to JPEG, and writes a timestamp CSV containing frame index, elapsed time, CameraX image timestamp, dimensions and mean luminance.

This is **not yet a clinical pupillometer and does not measure validated PLR latency**. It does not use the phone flash as a scientific stimulus, does not contain the trained U-Net weights, and does not make diagnostic claims.

## Experiment
1. Install/build on the target phone.
2. Give camera permission.
3. Use the rear camera and keep the eye in view.
4. Keep the phone stable and do not stare into a bright light.
5. Press START and acquire one 10-second eye recording.
6. Press STOP (or let the 10 seconds finish).
7. Pull the session folder from app-specific external storage.

## Output
`NeuroPulse_<timestamp>/frames/*.jpg`
`NeuroPulse_<timestamp>/frames.csv`

The saved frames are intended for offline U-Net inference and waveform analysis in the next stage.
